<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<header>
		<div>
			<a href="index.php">
				<button style="background-color: purple; width: 300px; height: 65px; display: inline-block; margin-left: 260px; font-size: 20px">Home Page</button>
			</a>
			<a href="login.php">
				<button style="background-color: purple; width: 300px; height: 65px; display: inline-block; margin-left: 30px; font-size: 20px">Login Page</button>
			</a>
			<a href="signup.php" class="button">
				<button style="background-color: purple; width: 300px; height: 65px; display: inline-block; margin-left: 30px; font-size: 20px">Sign up Page</button>
			</a>
		</div>
	</header>

</body>
</html>