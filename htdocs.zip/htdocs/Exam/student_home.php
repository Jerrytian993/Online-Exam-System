
<?php
require_once 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>jij</title>
</head>
<body style="background-color: chocolate">
	<h1 style="text-align: center; font-size: 60px; padding: 50px">Student's Exam Space</h1>
	<a href="test_taking.php">
		<button style="background-color: cyan; height: 200px; width: 200px; font-size: 30px; margin:auto; display:block">Take test</button>
	</a>
	<a href="viewscore.php">
		<button style="background-color: red; height: 200px; width: 200px; font-size: 30px; margin:auto; display:block">View scores</button>
	</a>
</body>
</html>
