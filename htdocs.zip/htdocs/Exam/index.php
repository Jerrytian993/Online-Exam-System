<?php
require 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color: green">
	<h1 style="text-align: center; font-size: 60px; padding: 50px">Online Exam System</h1>
	<a href="signup.php">
		<button style="background-color: orange; height: 200px; width: 200px; font-size: 30px;  display:block; margin-left: 560px; display: inline-block;">Sign up</button>
	</a>
	<a href="login.php">
		<button style="background-color: purple; height: 200px; width: 200px; font-size: 30px;  display:block; display:inline-block; margin-left: 20px;">Login</button>
	</a>
</body>
</html>