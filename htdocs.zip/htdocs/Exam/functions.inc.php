<?php

function createUser($conn, $name, $password, $identity){
	$sql = "INSERT INTO examdb (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')";
}




