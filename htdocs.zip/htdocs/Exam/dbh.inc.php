<?php 


$servername = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "examdb";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);