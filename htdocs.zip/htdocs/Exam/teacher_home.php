<!DOCTYPE html>
<html>
<head>
	<title>Teacher's Exam space</title>
</head>
<body style="background-color: purple">
	<h1 style="text-align: center; font-size: 60px; padding: 50px">Teacher's Exam space</h1>
	<a href="testcreation.php">
		<button style="background-color: orange; height: 200px; width: 200px; font-size: 30px;  display:block; margin-left: 550px; display: inline-block;">Create test</button>
	</a>
	<a href="viewscore.php">
		<button style="background-color: orange; height: 200px; width: 200px; font-size: 30px;  display:block; margin-left: 20px; display: inline-block;">View scores</button>
	</a>
</body>
</html>









